# Author: Jeremy Rubin
# Date: 6/16/23                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
### Functions to run CLUSSO as well as generate performance metrics

# Compute (a,b) for drawing pi from discrete uniform
# Given desired expected value and variance
calc_ab = function(sigma_sq_m,mu)
{
  H <- floor(sqrt(12*sigma_sq_m+1))
  
  # Make H odd
  if(H %% 2 == 0){H <- H - 1}
  a <- mu-(H-1)/2
  b <- mu+(H-1)/2
  
  return(c(a,b))
}

generate.design.matrices = function(n,mu,sigma_sq_m,sigma_sq,
                                    x1,x2,sigma1,sigma2,sigma.r,alpha_star,beta_star,
                                    w)
{
  H <- floor(sqrt(12*sigma_sq_m+1))
  
  # Make H odd
  if(H %% 2 == 0){H <- H - 1}
  a <- mu-(H-1)/2
  b <- mu+(H-1)/2
  
  p <- sample(a:b,size=n,replace=TRUE)
  
  P <- length(alpha_star)
  q <- length(beta_star)
  
  # ########## DESIGN MATRIX FOR BALANCING BY TAKING AVERAGE OF ACROSS ALL TUBULES/SEGMENTED OBJECTS PER FEATURE ################
  X.avg <- matrix(0,nrow=n,ncol=q)
  
  ########## DESIGN MATRIC FOR USING FULL INFORMATION/Xi_star MATRICES THAT HAVE ALL SEGMENTED OBJECTS######
  X.full <- array(1, dim=c(P,q,n))
  
  # Vector of outcomes
  Y <- rep(0,length(n))
  
  # True list of subpopulation/cluster labels/atrophic vs normal tubules
  # List of vectors, where each one is pi x 1
  cluster_labels <- vector(mode='list', length=n)
  
  # List of observed matrices 
  raw.X <- vector(mode='list', length=n)
  
  for(j in 1:n)
  {
    # Assuming that each subject has two truly informative tubules, 
    # One atrophic and one normal 
    # And rows of observed Xi are resampled from these two tubules with measurement
    # error
    Xi_star <- matrix(0,nrow=P,ncol=q)
   
    # First row is atrophic tubule, second one is normal tubule
    Xi_star[1,] <- rnorm(q,mean=x1,sd=sqrt(sigma1))
    Xi_star[2,] <- rnorm(q,mean=x2,sd=sqrt(sigma2))    
    
    # Pick rows from Xi_star to resample with replacement and added noise, then
    # appending these rows on to Xi_star to make the observed design matrix
    
    ### New code changes prob so that it samples normal/atrophic tubules in proportion 
    # To the true, set weights
    resamp.Xi.rows <- sample(1:nrow(Xi_star), size=p[j], replace=T,prob=c(w[j],1-w[j]))
    
    ###### resamp.Xi.rows contains true clustering/subpopulation assignments 
    resamp.Xi <- Xi_star[resamp.Xi.rows,]
    
    # Adding standard normal Gaussian measurement error to each resampled row
    resamp.Xi <- resamp.Xi + rnorm(nrow(resamp.Xi)*ncol(resamp.Xi),sd=sqrt(sigma.r))
    
    # Saving true cluster labels for observed Xi
    cluster_labels[[j]] <- c(resamp.Xi.rows)
    
    X <- resamp.Xi
    
    # Adding observed Xi to list of all Xi
    raw.X[[j]] <- X
    
    ### New code multiply rows of Xi_star by true normal/atrophic weights ### 
    Xi_star[1,] <- w[j] * Xi_star[1,]
    Xi_star[2,] <- (1-w[j]) * Xi_star[2,]
    
    Y[j] <- t(alpha_star) %*% Xi_star %*% beta_star + rnorm(n=1,mean=0,sd=sqrt(sigma_sq))
    
    X.avg[j,] <- colMeans(X)
    
    X.full[,,j] <- Xi_star
    
  }
  
  ########################## New code to do clustering followed by ###########
  #### Averaging by subpopulation before plugging into structured lasso 
  # Then take row averages among clusters and regress on list of c x q 
  # matrices, where c is the number of subpopulations 
  X.all <- do.call(rbind, raw.X)
  cluster.all <- do.call(c,cluster_labels)
  
  # do clustering on all data
  NMM.out <- Mclust(X.all,G=P)$classification
  
  # Save original full list of cluster labels and original full list of 
  # Estimated cluster labels
  cluster.accuracy.check <- cluster.all
  NMM.accuracy.check <- NMM.out
  
  # Making the cluster assignments from k-means the second column of the observed
  # Xi, and the true cluster labels the first column
  for(i in 1:n)
  {
    raw.X[[i]] <- cbind(cluster.all[1:p[i]],NMM.out[1:p[i]],raw.X[[i]])
    NMM.out <- NMM.out[(p[i]+1):length(NMM.out)]
    cluster.all <- cluster.all[(p[i]+1):length(cluster.all)]
  }
  
  # Estimate clustering accuracy by looking at all labels across subjects together for the two possible
  # correspondences of 1's/2's to original row labels or the complete opposite of the original row labels
  config1 <-  sum((cluster.accuracy.check==1 & NMM.accuracy.check==1) | 
                    (cluster.accuracy.check==2 & NMM.accuracy.check==2))/length(NMM.accuracy.check)
  config2 <- sum((cluster.accuracy.check==1 & NMM.accuracy.check==2) | 
                   (cluster.accuracy.check==2 & NMM.accuracy.check==1))/length(NMM.accuracy.check)
  
  clustering.accuracy <- max(config1,config2)
  
  # List of c x q matrices, where c is the number of clusters per subject
  # clust.X <- vector(mode='list', length=n)
  clust.X <- array(1, dim=c(P,q,n))
  
  # Binary indicator as to whether simulation should be thrown out because 
  # At least one subject had no tubules in one of the clusters
  no.clust <- F
  
  for(i in 1:n)
  {
    clust1.X <- raw.X[[i]][raw.X[[i]][,2]==1,]
    clust2.X <- raw.X[[i]][raw.X[[i]][,2]==2,]
    
    # Column two has the truly observed k-means cluster assignments
    if(is.null(dim(clust1.X)) | is.null(dim(clust2.X)))
    {
      no.clust <- T
      clust.X[,,i] <- matrix(0,nrow=P,ncol=q)
    }
    
    # For each subject, average tubules within each identified cluster and 
    # Make cluster ordering consistent across subjects
    
    # Check that there is at least one tubule that got classified into each 
    # cluster. Otherwise, going to drop subject
    
    # Each apply statement should produce a single row for the Xi generated by CLUSSO, and 
    # want to apply the appropriate weight w1 or 1-w1 for the respect normal/atrophic rows 
    
    else
    {
      ### New code to estimate weights for each row of final clust.X by computing 
      # The observed proportions of tubules belonging to cluster 1 and cluster 2 
      # from the EM/GMM clustering 
      w1 <- nrow(clust1.X)/nrow(raw.X[[i]])
      
      clust.X[,,i] <- rbind(w1*apply(clust1.X[,3:ncol(clust1.X)],MARGIN=2,mean),
                               (1-w1)*apply(clust2.X[,3:ncol(clust2.X)],MARGIN=2,mean))
    }
  }
  
  return(list(Y,X.avg,clust.X,X.full,clustering.accuracy,no.clust))
}

# Compute simulation metrics 
simulation.results = function(beta_hat,beta_star,alpha_hat,Y,X)
{
  # L1 normalize beta_star
  beta_star <- beta_star/sum(abs(beta_star))

  TPR <- (length(intersect(which(beta_hat!=0),which(beta_star!=0)))/length(which(beta_star!=0)))*100
  FPR <- (length(intersect(which(beta_hat!=0),which(beta_star==0)))/length(which(beta_star==0)))*100
  bias <- sum(abs(beta_star-beta_hat))
  
  ########## For MSE, need to mean-center Y and the p x q predictors
  # Mean-centering but not scaling the variance for outcome
  Y <- scale(Y,scale=FALSE)
  
  # Get mean of the Xi's 
  X.mean <- apply(X, c(1,2), mean)
  
  SSE <- 0
  
  for(i in 1:(dim(X)[3]))
  {
    # Mean-center Xi's 
    X[,,i] <- X[,,i] - X.mean
    SSE <- SSE + (Y[i] - t(alpha_hat) %*% X[,,i] %*% beta_hat)^2
  }
  
  MSE <- (1/dim(X)[3]) * SSE
  #################################################################
  
  results <- c(TPR,FPR,bias,MSE)
  
  return(results)
}

# Compute MSE from estimated beta_hat and alpha_hat
slasso.mse = function(X.train,Y.train,X.test,Y.test,alpha_init,beta_init,lambda)
{
  slasso_results <- Mainfunction_albet(X.train,Y.train,alpha_init,beta_init,lambda)
  beta_hat <- slasso_results[[2]]
  alpha_hat <- slasso_results[[1]]
  
  ### New MSE code to try to properly center everything
  ########## For MSE, need to mean-center Y and the p x q predictors
  # Mean-centering but not scaling the variance for outcome
  Y.test <- scale(Y.test,scale=FALSE)
  
  # Get mean of the Xi's 
  X.mean.test <- apply(X.test, c(1,2), mean)
  
  SSE <- 0
  
  for(i in 1:(dim(X.test)[3]))
  {
    # Mean-center Xi's 
    X.test[,,i] <- X.test[,,i] - X.mean.test
    SSE <- SSE + (Y.test[i] - t(alpha_hat) %*% X.test[,,i] %*% beta_hat)^2
  }
  
  MSE <- (1/dim(X.test)[3]) * SSE
  
  ### Old code on/before 6/16/23
  # SSE <- 0
  # 
  # for(i in 1:(dim(X.test)[3])){
  #   SSE <- SSE + (Y.test[i] - t(alpha_hat) %*% X.test[,,i] %*% beta_hat)^2
  #   }
  # MSE <- (1/dim(X.test)[3]) * SSE
  
  return(MSE)
}

# Make folds for cross-validation for picking lambda for structured lasso
# Takes in number of subjects which are being used for the training dataset
CV.make.folds = function(nTrain)
{
  # Compute sample sizes
  sampleSizeF <- floor(1/5 * nTrain)
  
  # Create the randomly-sampled indices for the dataframe. Use setdiff() to avoid 
  # overlapping subsets of indices
  indicesF1 <- sort(sample(1:nTrain,size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,indicesF1)
  
  indicesF2 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2))
  
  indicesF3 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2,indicesF3))
  
  indicesF4 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesF5 <- setdiff(indicesNotF,indicesF4)
  
  return(list(indicesF1,indicesF2,indicesF3,indicesF4,indicesF5))
}

# Uses cross-validation to get MSE for a given lambda
lambda.CV.mse = function(X.train,Y.train,alpha_init,beta_init,lambda){

nfolds <- 5
folds <- CV.make.folds(dim(X.train)[3])
CV.fold.matrix <- diag(nfolds)
mse.vec <- rep(0,nfolds)

for(i in 1:length(folds))
{
  fold.setup <- CV.fold.matrix[i,]
  train.fold <- which(fold.setup==0)
  test.fold <- which(fold.setup==1)
  cv.train.ind <- sort(c(unlist(folds[train.fold])))
  cv.test.ind <- sort(c(unlist(folds[test.fold])))
  mse.vec[i] <- slasso.mse(X.train[,,cv.train.ind],Y.train[cv.train.ind],X.train[,,cv.test.ind],
                           Y.train[cv.test.ind],alpha_init,beta_init,lambda)
}

return(mean(mse.vec))

}

# Function to compare the performance of CLUSSO to the naive method and the Full Information Structured Lasso
CLUSSO.performance = function(n,mu,sigma_sq_m,sigma_sq,
                              x1,x2,sigma1,sigma2,sigma.r,alpha_star,beta_star,lambda.grid,w)
{
  # Initialize beta coefficient vector
  beta_init <- rnorm(q)
  
  CLUSSO.stuff <- generate.design.matrices(n,mu,sigma_sq_m,sigma_sq,
                                           x1,x2,sigma1,sigma2,sigma.r,alpha_star,beta_star,w)

  Y <- CLUSSO.stuff[[1]]
  X.avg <- CLUSSO.stuff[[2]]
  clust.X <- CLUSSO.stuff[[3]]
  X.full <- CLUSSO.stuff[[4]]
  clustering.accuracy <- CLUSSO.stuff[[5]]
  no.clust <- CLUSSO.stuff[[6]]
  
  # Check if there are any remaining NaNs, in any subject, if so, set no.clust <- T
  # and consider this a simulation run that you will throw away
  for(i in 1:n){if(sum(is.nan(clust.X[,,i]))>0){no.clust <- T}}
  
  if(!no.clust)
  {
    avg.fit <- cv.glmnet(X.avg,Y,nfolds = 5)
    beta_coeff <- as.vector(coef(avg.fit, s = "lambda.min"))
    intercept <- beta_coeff[1]
    beta_hat.avg <- beta_coeff[-1]
    
    beta_hat.avg.original <- beta_hat.avg
    beta_hat.avg <- beta_hat.avg/sum(abs(beta_hat.avg))
    zero.inds <- abs(beta_hat.avg)<0.001
    beta_hat.avg[abs(beta_hat.avg)<0.001]=0 
    beta_star <- beta_star/sum(abs(beta_star))
    
    TPR.avg <- (length(intersect(which(beta_hat.avg!=0),which(beta_star!=0)))/length(which(beta_star!=0)))*100
    FPR.avg <- (length(intersect(which(beta_hat.avg!=0),which(beta_star==0)))/length(which(beta_star==0)))*100
    bias.avg <- sum(abs(beta_star-beta_hat.avg))
  
    ## MSE
    beta_hat.avg.original[zero.inds]=0
    SSE <- 0
  
    for(r in 1:length(Y)){SSE <- SSE + (Y[r] - beta_hat.avg.original %*% X.avg[r,] - intercept)^2}
    MSE.avg <- SSE / length(Y)
    
    ########### FULL INFORMATION BALANCING RESULTS #################################################
    alpha_init <- rnorm(dim(X.full)[1])
    
    ############ CV-BASED LAMBDA ########################################################
    mse.full.lambda <- sapply(lambda.grid,lambda.CV.mse,X.train=X.full,
                              Y.train=Y,
                              alpha_init=alpha_init,beta_init=beta_init)
    lambda.full <- lambda.grid[which(mse.full.lambda==min(mse.full.lambda))][1]
    ####################################################################################
    
    slasso_results.full <- Mainfunction_albet(X.full,Y,alpha_init,beta_init,lambda.full)
    beta_hat.full <- slasso_results.full[[2]]
    alpha_hat.full <- slasso_results.full[[1]]
    
    simulation.stuff <- simulation.results(beta_hat.full,beta_star,alpha_hat.full,Y,X.full)
    TPR.full <- simulation.stuff[1]
    FPR.full <- simulation.stuff[2]
    bias.full <- simulation.stuff[3]
    MSE.full <- simulation.stuff[4]
    
    ########### FULL INFORMATION BALANCING RESULTS #################################################
    alpha_init <- rnorm(dim(clust.X)[1])
    
    ############ CV-BASED LAMBDA ########################################################
    mse.clust.lambda <- sapply(lambda.grid,lambda.CV.mse,X.train=clust.X,
                               Y.train=Y,
                               alpha_init=alpha_init,beta_init=beta_init)
    lambda.clust <- lambda.grid[which(mse.clust.lambda==min(mse.clust.lambda))][1]
    ####################################################################################
    
    clust.fit <- Mainfunction_albet(clust.X,Y,alpha_init,beta_init,lambda.clust)
    alpha_hat.clust <- clust.fit[[1]]  
    beta_hat.clust <- clust.fit[[2]]
    
    simulation.stuff <- simulation.results(beta_hat.clust,beta_star,alpha_hat.clust,Y,clust.X)
    TPR.clust <- simulation.stuff[1]
    FPR.clust <- simulation.stuff[2]
    bias.clust <- simulation.stuff[3]
    MSE.clust <- simulation.stuff[4]
    
    performance.results <- rbind(c(TPR.clust,TPR.avg,TPR.full),
                                 c(FPR.clust,FPR.avg,FPR.full),
                                 c(bias.clust,bias.avg,bias.full),
                                 c(MSE.clust,MSE.avg,MSE.full))  
      
    rownames(performance.results) <- c("TPR","FPR","L1 norm of bias","MSE")
    colnames(performance.results) <- c("CLUSSO","Average balancing","Full information")
    
    return(list(performance.results,c(lambda.clust,lambda.full),clustering.accuracy))
    
    # Returning everything as null if one of the subjects had no tubules in a cluster
  } else{return(vector(mode = "list", length = 3))}
  
}
