# Date: 7/20/23
# Helper function for doing structured lasso fit

mat_vec_prd<-function(X_tr,alph,ord)
{d0=dim(X_tr); 
 
  
 if(ord=='vec_mat')
 {X_al=matrix(rep(0,d0[3]*d0[2]),nrow=d0[3])
 for (i in 1:d0[3])
 {  X_al[i,]=t(alph)%*%X_tr[,,i]}
 }
 if(ord=='mat_vec')
 {X_al=matrix(rep(0,d0[3]*d0[1]),nrow=d0[3])
 for (i in 1:d0[3])
 {  X_al[i,]=X_tr[,,i]%*%alph}
 }
X_al
}