# Author: Jeremy Rubin
# Date: 9/22/23
# Example code for running CLUSSO and naive approach on a dataset

### Packages required: glmnet and mclust
# install.packages(c("glmnet","mclust"))
rm(list=ls())

library(glmnet)
library(mclust)

set.seed(87543)

### Assumes that all of these files are in your current working directory #####
source("SLasso_MSE.R")
source("coefficient.R")
source("K_prdu.R")
source("Mainfunction_albet.R")
source("mat_vec_prd.R")

######## Generate synthetic data
## Number of subjects
n <- 100

# Assume G=2 clusters
G <- 2

# Number of initializations for optimization of CLUSSO objective function on real data
M <- 5

## Define lower/upper limits for number of objects observed by each subject
low.obj.bound <- 50
high.obj.bound <- 100

# Define weights to pre-multiply feature matrices by for generating outcomes
alpha_weights <- 0:1

# Define mean and variance for noise in observed outcomes
Y.noise.mean <- 0
Y.noise.sd <- 5

# Number of folds for cross-validation for average balancing method
n.avg.folds <- 5

##### Defining true feature coefficients for purposes of data example, so that
# Xi clearly have an association with the outcome that is determined by these
# coefficients
# Note that these are not observed in real data
beta_star <- c(rep(5,2),rep(0,2),rep(2,4),rep(0,1),rep(10,1))

# Number of features
q <- length(beta_star)

# Grid of regularization parameters to search over for CLUSSO
lambda.grid <- seq(0.1,20,0.1)

# Coefficient treshold
beta_thresh <- 0.001

### List of design matrices
X.list <- vector("list", n)

# List of scalar outcomes
Y <- rep(0,n)

# Naive average balancing matrix
X.avg <- matrix(0,nrow=n,ncol=q)

## Generate number of objects for each subject
obj.count <- sample(low.obj.bound:high.obj.bound,size=n,replace = T)

for(i in 1:n)
{
  ### Generate Xi for each subject with number of rows equal to number of objects 
  # for that subject, and number of columns equal to q/number of features
  X.list[[i]] <- matrix(rnorm(obj.count[i]*q),nrow=obj.count[i],ncol=q)
  
  # Take average across objects to get a row of the naive average feature matrix
  X.avg[i,] <- colMeans(X.list[[i]])
  
  # Setting scalar outcomes Y to be feature matrices post-multiplied by feature coefficients 
  # and pre-multiplied by random 0/1 weights for each object plus some noise
  Y[i] <- sample(alpha_weights,size=obj.count[i],replace = T) %*% X.list[[i]] %*% beta_star + rnorm(1,mean=Y.noise.mean,
                                                                                                    sd=Y.noise.sd)
}

# Row-wise concatenatation of all Xi matrices across subjects to jointly cluster objects into G clusters
X.all <- do.call(rbind, X.list)

# Assign clustering labels to all subjects using GMM-based clustering
clust.label <- Mclust(X.all,G)$classification

# Append cluster labels to the design matrices
for(i in 1:n)
{
  # Column-wise combine cluster labels with Xi's 
  X.list[[i]] <- cbind(clust.label[1:obj.count[i]],X.list[[i]])
  clust.label <- clust.label[(obj.count[i]+1):length(clust.label)]
}

# cluster-averaged Xi's to be fit with structured lasso for CLUSSO 
clust.X <- array(1, dim=c(G,q,n))

for(i in 1:length(obj.count))
{
  ## Separate each Xi into two submatrices, one for rows assigned to cluster 1
  # and one assigned to twos assigned to cluster 2
  clust1.X <- X.list[[i]][X.list[[i]][,1]==1,]
  clust2.X <- X.list[[i]][X.list[[i]][,1]==2,]
  
  # Weights for each cluster are the observed proportion of objects in each cluster
  w1 <- nrow(clust1.X)/nrow(X.list[[i]])
  w2 <- nrow(clust2.X)/nrow(X.list[[i]])
  
  ## Average feature values within each cluster and multiply by the appropriate row-weight
  clust.X[,,i] <- rbind(w1*apply(clust1.X[,2:ncol(clust1.X)],MARGIN=2,mean),
                        w2*apply(clust2.X[,2:ncol(clust2.X)],MARGIN=2,mean))
}

# Store values of objectie function
obj.CLUSSO.vec <- rep(0,M)

# Matrix to store beta hat values for CLUSSO fpr each of M iterations
beta.matrix <- matrix(0,nrow=M,ncol=dim(clust.X)[2])

# Scale outcome variable for CLUSSO fit
Y.CLUSSO <- scale(Y,scale=FALSE)

# Calculate averages for each feature across subjects
X.mean <- apply(clust.X, c(1,2), mean)

# Centered Xi's 
cent.clust.X <- clust.X

# Mean center Xi's 
for(d in 1:(dim(cent.clust.X)[3])){cent.clust.X[,,d] <- cent.clust.X[,,d] - X.mean}

for(m in 1:M)
{
  # Initialize alpha and beta coefficient vectors for structured lasso - need to be nonzero
  alpha_init <- rnorm(G)
  beta_init <- rnorm(dim(clust.X)[2])
  
  # Compute MSEs for grid of regularization/lambda values
  mse.clust.lambda <- sapply(lambda.grid,lambda.CV.mse,X.train=clust.X,
                             Y.train=Y,
                             alpha_init=alpha_init,beta_init=beta_init)
  
  # Pick the first lambda that gives the lowest MSE
  lambda.clust <- lambda.grid[which(mse.clust.lambda==min(mse.clust.lambda))][1]
  
  # Fit CLUSSO model
  CLUSSO.fit <- Mainfunction_albet(clust.X,Y,alpha_init,beta_init,lambda.clust)
  alpha_hat <- CLUSSO.fit[[1]]
  beta_hat <- CLUSSO.fit[[2]]
  
  beta.matrix[m,] <- beta_hat
  
  # Calculate objective function for CLUSSO to see which beta minimizes the
  # objective function
  obj <- 0
  for(k in 1:(dim(cent.clust.X)[3]))
  {
    obj <- obj + (Y.CLUSSO[k] - t(alpha_hat) %*% cent.clust.X[,,k] %*% beta_hat)^2
  }
  
  obj <- obj + sum(abs(beta_hat))*lambda.clust
  
  obj.CLUSSO.vec[m] <- obj
} 

# Pick the beta coefficients that minimize the objective function
beta_hat <- beta.matrix[which(obj.CLUSSO.vec==min(obj.CLUSSO.vec)),]

# Naive approach fit: Five-fold cross-validation on the matrix generated by 
# Averaging across all objects for each subject
avg.fit <- cv.glmnet(X.avg,Y,nfolds = n.avg.folds)
beta_coeff <- as.vector(coef(avg.fit, s = "lambda.min"))
intercept <- beta_coeff[1]
beta_hat.avg <- beta_coeff[-1]

beta_hat.avg.original <- beta_hat.avg

# Zero out indices corresponding to entries of estimated L1-normalized beta 
# coefficient vector that have magnitude less than 0.001
beta_hat.avg <- beta_hat.avg/sum(abs(beta_hat.avg))
zero.inds <- abs(beta_hat.avg)<beta_thresh
beta_hat.avg[abs(beta_hat.avg)<beta_thresh]=0
beta_hat.avg.original[zero.inds]=0

# Compute MSE for naive approach
SSE <- 0

for(r in 1:length(Y))
{
  SSE <- SSE + (Y[r]-beta_hat.avg.original %*% X.avg[r,] - intercept)^2
}

MSE.avg <- (1/length(Y)) * SSE

## Compute MSE for CLUSSO
SSE.CLUSSO <- 0

for(b in 1:(dim(cent.clust.X)[3]))
{
  SSE.CLUSSO <- SSE.CLUSSO + (Y.CLUSSO[b] - t(alpha_hat) %*% cent.clust.X[,,b] %*% beta_hat)^2  
}

MSE.CLUSSO <- (1/dim(cent.clust.X)[3]) * SSE.CLUSSO

combined.coeff <- cbind(beta_hat,beta_hat.avg)
colnames(combined.coeff) <- c("CLUSSO","Naive approach")
rownames(combined.coeff) <- colnames(X.avg)

# Estimated beta coefficients for both CLUSSO and the naive approach
combined.coeff

# Estimated MSEs for CLUSSO and the naive approach
c(MSE.CLUSSO,MSE.avg)