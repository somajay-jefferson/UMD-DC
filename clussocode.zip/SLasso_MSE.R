# Author: Jeremy Rubin
# Date: 7/20/23                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
## Functions to compute MSE for structured Lasso across a grid of regularization parameters
# with cross-validation

# Do structured lasso fit on training Xi's and Yi's and then compute MSE 
# using structured lasso fit on test Xi's and Yi's 
slasso.mse = function(X.train,Y.train,X.test,Y.test,alpha_init,beta_init,lambda)
{
  slasso_results <- Mainfunction_albet(X.train,Y.train,alpha_init,beta_init,lambda)
  beta_hat <- slasso_results[[2]]
  alpha_hat <- slasso_results[[1]]
  
  # Mean-centering test Y 
  Y.test <- scale(Y.test,scale=FALSE)
  
  # Get mean of the Xi's 
  X.mean.test <- apply(X.test, c(1,2), mean)
  
  # Compute MSE
  SSE <- 0
  
  for(i in 1:(dim(X.test)[3]))
  {
    # Mean-center Xi's 
    X.test[,,i] <- X.test[,,i] - X.mean.test
    SSE <- SSE + (Y.test[i] - t(alpha_hat) %*% X.test[,,i] %*% beta_hat)^2
  }
  
  MSE <- (1/dim(X.test)[3]) * SSE
  
  return(MSE)
}

# Make folds for cross-validation for picking lambda for structured lasso
# Takes in number of subjects which are being used for the training dataset
CV.make.folds = function(nTrain)
{
  # Compute sizes for each fold
  sampleSizeF <- floor(1/5 * nTrain)
  
  # Picking indices for each fold 
  indicesF1 <- sort(sample(1:nTrain,size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,indicesF1)
  
  indicesF2 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2))
  
  indicesF3 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2,indicesF3))
  
  indicesF4 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesF5 <- setdiff(indicesNotF,indicesF4)
  
  return(list(indicesF1,indicesF2,indicesF3,indicesF4,indicesF5))
}

# Get cross-validated MSE using structured lasso for a particular lambda value
lambda.CV.mse = function(X.train,Y.train,alpha_init,beta_init,lambda){

# Define the different folds for each round of cross-validation
nfolds <- 5
folds <- CV.make.folds(dim(X.train)[3])
CV.fold.matrix <- diag(nfolds)
mse.vec <- rep(0,nfolds)

for(i in 1:length(folds))
{
  fold.setup <- CV.fold.matrix[i,]
  
  # Make training/testing split
  # Four folds are for training and one fold is for testing
  train.fold <- which(fold.setup==0)
  test.fold <- which(fold.setup==1)
  cv.train.ind <- sort(c(unlist(folds[train.fold])))
  cv.test.ind <- sort(c(unlist(folds[test.fold])))
  
  # Compute MSE for given training/testing split
  mse.vec[i] <- slasso.mse(X.train[,,cv.train.ind],Y.train[cv.train.ind],X.train[,,cv.test.ind],
                           Y.train[cv.test.ind],alpha_init,beta_init,lambda)
}

return(mean(mse.vec))

}

