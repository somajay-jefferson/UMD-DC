# Code for Novel Scalar-on-matrix Regression for Unbalanced Feature Matrices Biometric Practice Paper

This code provides a framework for analyzing data in a scalar-on-matrix regression setting where the feature matrices have different numbers of rows. 

All R scripts except for CLUSSO_Data_Example.R provide helper functions to run the CLUSSO_Data_Example.R Script. 

## Installation

To run these scripts, you need to have R installed. You can install the required packages by using the following commands:

```R
install.packages("glmnet")
install.packages("mclust")
```

## Usage

1. First, load the necessary packages and helper functions: 

```R
library(glmnet)
library(mclust)
source("SLasso_MSE.R")
source("coefficient.R")
source("K_prdu.R")
source("Mainfunction_albet.R")
source("mat_vec_prd.R")
```

2. Choose values of parameters for data generation. This includes setting the 

Number of subjects (n)

The number of clusters to identify with CLUSSO (G)

The number of initializations for optimizing the CLUSSO objective function (M)

The beta_star coefficient vector (beta_star) with length equal to the number of imaging features (q)

Grid of lambda's to optimize over for CLUSSO (lambda.grid)

Number of objects observed for each subject (in range of low.obj.bound to high.obj.bound)

Weights to pre-multiply feature matrices by which generate the outcomes (alpha_weights), must be of length G

Mean and variance of noise in observed scalar outcomes (Y.noise.mean, Y.noise.sd)

Number of folds for cross-validation for average balancing method (n.avg.folds)

Note that even if the number of clusters G is changed, there are several places in the code that woul need to be modified to accomodate more than two clusters. For example, for the for loop in lines 104-118, submatrices, weights, and averaging would need to be done across more clusters than the two which are hard-coded in these lines. 

3. Do the analysis! 

The CLUSSO_Data_Example.R script will perform both CLUSSO and the naive averaging approach on the synthetic scalar-on-matrix regression method, again assuming we are interested in identifying two clusters to generate estimated beta_star coefficients as well mean squared error (MSEs) on the same data used to estimate the beta_star coefficients. 

## Contact Information

For questions about the code, please reach the first-author, Jeremy Rubin, of the corresponding manuscript at RubinJ@pennmedicine.upenn.edu 




