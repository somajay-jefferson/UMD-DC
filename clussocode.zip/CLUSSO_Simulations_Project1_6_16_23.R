# Author: Jeremy Rubin
# Date: 6/16/23
# Code to run CLUSSO simulations

rm(list=ls())

library(tictoc)
library(glmnet)
library(mclust)
source("Mainfunction_albet.r")
source("CLUSSO_Functions_Project1_6_16_23.R")
source("mat_vec_prd.r")
set.seed(83022)

mu <- 40
sigma_sq_m <- 5
sigma1 <- 1
sigma2 <- 3
x1 <- 2
x2 <- 5
sigma_sq <- 1
P <- 2 
lambda.grid <- seq(0.5,5,0.5) 
nsim <- 1000

most.sim <- expand.grid(1,c(0.4,0.8),c(300,500,700,900,1100,1500,2000),c(10,50,100,150,200))
extra.sim <- expand.grid(seq(1,50,5),0.8,500,10)
param.comb <- rbind(most.sim,extra.sim)
colnames(param.comb) <- c("sigma.r","s","n","q")

#### New code to read in simulation parameter combination as command line argument
j = as.numeric(commandArgs(TRUE)[[1]])
# for(j in 1:nrow(param.comb)){
# j <- 1

q <- param.comb[j,4]
n <- param.comb[j,3]
s2 <- param.comb[j,2]
sigma.r <- param.comb[j,1]
  
# Record time for each simulation
time.vec <- rep(0,nsim)
  
# Average clustering per simulation
clust.vec <- rep(0,nsim)
  
#### Statistic distributions to generate plots to check for symmwetric/skewed distributions
# Adding in MSE for statistic
CLUSSO.stat.mat <- matrix(0,nrow=nsim,ncol=4)
Avg.stat.mat <- matrix(0,nrow=nsim,ncol=4)
Full.stat.mat <- matrix(0,nrow=nsim,ncol=4)
  
# Recording lambda chosen with cross-validation for all structured lasso methods
lambda.mat <- matrix(0,nrow=nsim,ncol=2)
  
alpha_star <- sample(1:4,size=P,replace=TRUE)
beta_star <- sample(1:4,size=q,replace=TRUE)
  
if(s2>0)
{
  beta_ind <- sample(1:length(beta_star),size=floor(s2*length(beta_star)),replace=FALSE)
  beta_star[beta_ind] <- 0
}
  
# Due to rounding issues, true sparsity level may be slightly different from the 
# One which we specify 
s2 <- round(1-sum(beta_star!=0)/length(beta_star),digits=3)
  
### Then the weights for the atrophic rows are 1 - weights for the normal rows ###
w <- sample(seq(.2,.8,.1),size=n,replace=TRUE)
  
for(i in 1:nsim)
{
  set.seed(i)
  print(paste("Simulation number: ",i))
  tic()
    
  CLUSSO.stuff <- CLUSSO.performance(n,mu,sigma_sq_m,sigma_sq,
                                       x1,x2,sigma1,sigma2,sigma.r,
                                       alpha_star,beta_star,lambda.grid,w)
  exectime <- toc()
  exectime <- exectime$toc- exectime$tic
  time.vec[i] <- exectime
    
  while(is.null(CLUSSO.stuff[[1]]))
  {
    tic()
    CLUSSO.stuff <- CLUSSO.performance(n,mu,sigma_sq_m,sigma_sq,
                                         x1,x2,sigma1,sigma2,sigma.r,
                                         alpha_star,beta_star,lambda.grid,w)
    exectime <- toc()
    exectime <- exectime$toc- exectime$tic
    time.vec[i] <- exectime  
  }
  
    lambda.mat[i,] <- CLUSSO.stuff[[2]]
    clust.vec[i] <- CLUSSO.stuff[[3]]
    CLUSSO.stat.mat[i,] <- CLUSSO.stuff[[1]][,1]
    Avg.stat.mat[i,] <- CLUSSO.stuff[[1]][,2]
    Full.stat.mat[i,] <- CLUSSO.stuff[[1]][,3]
}
  
  CLUSSO.medians <- apply(MARGIN=2,CLUSSO.stat.mat,FUN=median)
  Avg.medians <- apply(MARGIN=2,Avg.stat.mat,FUN=median)
  Full.medians <- apply(MARGIN=2,Full.stat.mat,FUN=median)
  
  median.mat <- cbind(CLUSSO.medians,Avg.medians,Full.medians)
  
  rownames(median.mat) <- c("TPR","FPR","L1 norm of bias","MSE")
  colnames(median.mat) <- c("CLUSSO","Average balancing","Full information")
  colnames(lambda.mat) <- c("CLUSSO","Full information")
  
  paste("Average time taken per simulation: ",mean(time.vec))
  paste("Average classification accuracy: ",mean(clust.vec))
  
  CLUSSO.file=paste("sigma_r_",sigma.r,"_s_",s2,"_n_",n,"_q_",q,sep="")
  
  write.csv(median.mat,file=paste("CLUSSO/median_stats/6_16_23_full_CLUSSO_performance",CLUSSO.file,".csv")) 
  write.csv(lambda.mat,file=paste("CLUSSO/lambdas/6_16_23_full_CLUSSO_lambdas_",CLUSSO.file,".csv"))
  
  extra_stats <- c(mean(time.vec),mean(clust.vec)*100)
  names(extra_stats)<- c("Average time taken per simulation","Average classification accuracy")
  write.csv(extra_stats,file=paste("CLUSSO/extra_stats/6_16_23_full_CLUSSO_extra_stats_",CLUSSO.file,".csv"))
# }