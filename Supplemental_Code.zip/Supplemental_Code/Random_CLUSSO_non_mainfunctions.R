# Author: Jeremy Rubin
# Date: 11/29/24
# Random CLUSSO functions

# Function to help calculate bootstraped alpha hat, beta hat, and also
# return the chosen lambda/regularization parameter 
bootstrap.estimates = function(b,raw.X,Y,lambda.grid,sample.weights,thresh)
{
  print(paste("Bootstrap number: ",b))
  
  ## Draw a bootstrap sample of size n with replacement from original training
  # set
  bootstrap.ind <- sample(1:length(raw.X),size=length(raw.X),replace=T)  
  
  # Draw bootstrapped feature matrices and outcome
  new.X <- raw.X[bootstrap.ind]
  new.Y <- Y[bootstrap.ind]
  
  # Forcing q1=q2=sqrt(q) features, but this can be customized to a different
  # number of features
  # The - 1 comes from the fact that we are storing the estimated clustering 
  # labels in the first column of the feature matrices
  q1 <- floor(sqrt(ncol(raw.X[[1]])-1))
  
  # Pass in zero sampling weights to uniformly subsample image features
  # for first round of bootstrapping
  # Starting sampling at column 2 is due to the column 1 being the estimated
  # cluster labels 
  if(sum(sample.weights)==0)
  {
    sub.covar <- sort(sample(2:ncol(raw.X[[1]]),size=q1,replace=F))  
  }
  
  # Pass in L1-normalized importance measures for second round of bootstrapping
  # to subsample image features in proportion to importance measures
  # Starting sampling at column 2 is due to the column 1 being the estimated
  # cluster labels 
  else
  {
    
    sub.covar <- sort(sample(2:ncol(raw.X[[1]]),size=q1,replace=F,
                             prob=sample.weights/sum(abs(sample.weights))))
  }
  
  for(i in 1:length(new.X))
  {
    # For the new, bootstrapped feature matrices, pull out only the columns
    # with the subsampled image features and also carry over the estimated
    # clustering labels/first column
    new.X[[i]] <- new.X[[i]][,c(1,sub.covar)]
    
    # Bootstrap pi tubules with replacement for each feature matrix
    bootstrap.obj <- sample(1:nrow(new.X[[i]]),
                            size=nrow(new.X[[i]]),replace=T)
    new.X[[i]] <- new.X[[i]][bootstrap.obj,]
    
  }
  
  ## Essentially run CLUSSO on the bootstrapped sample, just you already
  ## have the estimated clustering levels already
  # Thresh is the threshold you want to use for iterative 
  # steps of the structured lasso
  ## Returns alpha hat for your bootstrapped sample
  bootstrap.CLUSSO.est <- run.CLUSSO(new.X,new.Y,lambda.grid,thresh)
  bootstrap.alpha <- bootstrap.CLUSSO.est[[1]]
  bootstrap.beta <- bootstrap.CLUSSO.est[[2]]
  
  # Note that we subsampled a fraction of the original set of image features
  ## Any features not subsampled should be set to zero
  beta.final <- rep(0,length(sample.weights))
  
  # The indices of features that were subsampled range from 2:(number of features + 1)
  # Because the first column of the image feature matrices was the estimated clustering
  # labels, so subtracting one to get back to the indices 1:(number of features)
  sub.covar <- sub.covar - 1
  
  beta.final[sub.covar] <- bootstrap.beta
  
  # Return the bootstrap alpha hat and the bootstrap beta hat that has image feature 
  # effect estimates for the subsampled image features, and zero for the image 
  # features that were not subsampled
  return(c(bootstrap.alpha,beta.final))
}

# Run CLUSSO algorithm except these feature matrices (Xi's) already
# have their estimated clustering labels in the first column of the 
# Xi's. Passing in grid of lamba's to optimize over and and thresh
# is the coefficient threshold for the structured lasso fit
run.CLUSSO = function(X,Y,lambda.grid,thresh)
{
  n <- length(Y)
  
  # Settting up the variable for the CLUSSO matrices, a bunch of 
  # 2 x q matrices and there are n of them. The -1 reflects the first column
  # of the feature matrices being the estimated clustering labels
  
  clust.X <- array(1, dim=c(2,ncol(X[[1]])-1,n))
  
  for(i in 1:n)
  {
    # Pulling out the tubules for corresponding to each cluster using the
    # estimated clustering labels
    clust1.X <- as.matrix(X[[i]][X[[i]][,1]==1,])
    clust2.X <- as.matrix(X[[i]][X[[i]][,1]==2,])
    
    ## First checking the cases where either clust1.X or clust2.X is a vector 
    ## which means that only tubule was identified for cluster 1 or cluster 2, respectively
    if(is.vector(clust1.X) | is.vector(clust2.X) | nrow(clust1.X)<=1 | nrow(clust2.X)<=1)
    {
      # clust1.X is a vector but clust2.X is a matrix
      if((is.vector(clust1.X) | nrow(clust1.X)==1) & nrow(clust2.X)>1)
      {
        ## We know that clust1.X only has one row, cluster 1 only gets 1/(total #
        # tubules for cluster 1)
        w1 <- 1/nrow(X[[i]])
        
        # create CLUSSO balanced and weighted feature matrices
        clust.X[,,i] <- rbind(w1*clust1.X[2:length(clust1.X)],
                              (1-w1)*apply(clust2.X[,2:ncol(clust2.X)],MARGIN=2,mean))  
      }
      
      # clust2.X is a vector but clust1.X is a matrix 
      if((is.vector(clust2.X) | nrow(clust2.X)==1) & nrow(clust1.X)>1)
      {
        w1 <- nrow(clust1.X)/nrow(X[[i]])
        
        # create CLUSSO balanced and weighted feature matrices
        clust.X[,,i] <- rbind(w1*apply(clust1.X[,2:ncol(clust1.X)],MARGIN=2,mean),
                              (1-w1)*clust2.X[2:length(clust2.X)])
      }
      
      ## clust1.X and clust2.X are both vectors
      if((is.vector(clust1.X) & is.vector(clust2.X)) 
         | (nrow(clust1.X)==1 & is.vector(clust2.X))
         | (is.vector(clust2.X) & nrow(clust2.X)==1))
      {
        ## We know that clust1.X only has one row
        w1 <- 1/nrow(X[[i]])
        
        # create CLUSSO balanced and weighted feature matrices
        clust.X[,,i] <- rbind(w1*clust1.X[2:length(clust1.X)],
                              (1-w1)*clust2.X[2:length(clust2.X)])  
      }
    }
    
    # Else clause reflects the subject having at least two tubules in each cluster
    else
    {
      w1 <- nrow(clust1.X)/nrow(X[[i]])
      
      # create CLUSSO balanced and weighted feature matrices
      clust.X[,,i] <- rbind(w1*apply(clust1.X[,2:ncol(clust1.X)],MARGIN=2,mean),
                            (1-w1)*apply(clust2.X[,2:ncol(clust2.X)],MARGIN=2,mean))
    }
  }
  
  # Initialize alpha and beta coefficient vectors for the structured lasso
  alpha_init <- rnorm(dim(clust.X)[1])
  beta_init <- rnorm(dim(clust.X)[2])
    
  # Use cross-validation with structured lasso to pick the optimal lambda
  # Grid of lambdas to optimize over is lambda.grid, thresh is the coefficient
  # threshold for the structured lasso
  mse.clust.lambda <- sapply(lambda.grid,
                             lambda.CV.mse,
                             X.train=clust.X,
                             Y.train=Y,
                             alpha_init=alpha_init,
                             beta_init=beta_init,
                             thresh=thresh)
  
  # Pick the lambda that minimizes the MSE
  lambda.clust <- lambda.grid[which(mse.clust.lambda==min(mse.clust.lambda))][1]
  
  # Do structured lasso fit to get alpha hat and beta hat for CLUSSO 
  clust.fit <- Mainfunction_albet(clust.X,Y,alpha_init,beta_init,lambda.clust,thresh)
  alpha_hat.clust <- clust.fit[[1]]  
  beta_hat.clust <- clust.fit[[2]]  
   
  # Return alpha hat and bet hat CLUSSO
  return(list(alpha_hat.clust,beta_hat.clust))
}


# Do structured lasso fit on training Xi's and Yi's and then compute MSE 
# using structured lasso fit on test Xi's and Yi's
# Passing in training/testing Xi's and Yi's, along with 
# initializations of alpha hat and beta hat 
# as well as threshold for structured lasso
slasso.mse = function(X.train,Y.train,X.test,Y.test,alpha_init,beta_init,lambda,thresh)
{
  slasso_results <- Mainfunction_albet(X.train,Y.train,alpha_init,beta_init,lambda,thresh)
  beta_hat <- slasso_results[[2]]
  alpha_hat <- slasso_results[[1]]
  
  # Mean-centering test Y 
  Y.test <- scale(Y.test,scale=FALSE)
  
  # Get mean of the Xi's 
  X.mean.test <- apply(X.test, c(1,2), mean)
  
  # Compute MSE
  SSE <- 0
  
  for(i in 1:(dim(X.test)[3]))
  {
    # Mean-center Xi's 
    X.test[,,i] <- X.test[,,i] - X.mean.test
    SSE <- SSE + (Y.test[i] - t(alpha_hat) %*% X.test[,,i] %*% beta_hat)^2
  }
  
  MSE <- (1/dim(X.test)[3]) * SSE
  
  return(MSE)
}

# Make folds for cross-validation for picking lambda for structured lasso
# Takes in number of subjects which are being used for the training dataset
CV.make.folds = function(nTrain)
{
  # Compute sizes for each fold
  sampleSizeF <- floor(1/5 * nTrain)
  
  # Picking indices for each fold 
  indicesF1 <- sort(sample(1:nTrain,size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,indicesF1)
  
  indicesF2 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2))
  
  indicesF3 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesNotF <- setdiff(1:nTrain,c(indicesF1,indicesF2,indicesF3))
  
  indicesF4 <- sort(sample(indicesNotF, size=sampleSizeF))
  indicesF5 <- setdiff(indicesNotF,indicesF4)
  
  return(list(indicesF1,indicesF2,indicesF3,indicesF4,indicesF5))
}

# Get cross-validated MSE using structured lasso for a particular lambda value
# and threshold for the structured lasso
# Also passing in training Xi's and Yi's, as well as initializations for 
# alpha and beta 
lambda.CV.mse = function(X.train,Y.train,alpha_init,beta_init,lambda,thresh){
  
  # Define the different folds for each round of cross-validation
  nfolds <- 5
  folds <- CV.make.folds(dim(X.train)[3])
  CV.fold.matrix <- diag(nfolds)
  mse.vec <- rep(0,nfolds)
  
  for(i in 1:length(folds))
  {
    fold.setup <- CV.fold.matrix[i,]
    
    # Make training/testing split
    # Four folds are for training and one fold is for testing
    train.fold <- which(fold.setup==0)
    test.fold <- which(fold.setup==1)
    cv.train.ind <- sort(c(unlist(folds[train.fold])))
    cv.test.ind <- sort(c(unlist(folds[test.fold])))
    
    # Compute MSE for given training/testing split
    mse.vec[i] <- slasso.mse(X.train[,,cv.train.ind],Y.train[cv.train.ind],X.train[,,cv.test.ind],
                             Y.train[cv.test.ind],alpha_init,beta_init,lambda,thresh)
  }
  
  return(mean(mse.vec))
  
}

# Generate data for example code
# Pass in sample size, average number of pi's, variability of pi's, 
# variability in outcome, means of tubules in both clusters, variance in
# both of the clusters, variability in resampled tubules, 
# true alpha and beta coefficient vectors,
# proportion of tubules in cluster 1 for each subject
# and correlation of informative image features
generate.data = function(n,mu,sigma_sq_m,sigma_sq,
                                    x1,x2,sigma1,sigma2,
                                    sigma.r,alpha_star,beta_star,
                                    w,rho)
{
  # Setting up the upper and lower limits of pi to have specified mean
  # and variance
  H <- floor(sqrt(12*sigma_sq_m+1))
  
  # Make H odd
  if(H %% 2 == 0){H <- H - 1}
  a <- mu-(H-1)/2
  b <- mu+(H-1)/2
  
  p <- sample(a:b,size=n,replace=TRUE)
  
  G <- length(alpha_star)
  q <- length(beta_star)
  
  # Feature matrix for naive approach
  X.avg <- matrix(0,nrow=n,ncol=q)
  
  # Vector of outcomes
  Y <- rep(0,length(n))
  
  # Store list of observed feature matrices
  raw.X <- vector(mode='list', length=n)
  
  for(j in 1:n)
  {
    # Assuming every subject has a latent feature matrix of two rows, each row
    # having population feature averages for each cluster 
    Xi_star <- matrix(0,nrow=G,ncol=q)
    
    # Generate latent tubular feature matrices using a multivariate normal distribution
    # so that we have the flexibility to define the row covariance structure
    # and the column covariance structure
    mean_matrix <- as.matrix(rbind(rep(x1,q),rep(x2,q)))
    
    # Creating block diagonal correlation structure for the image feature effects
    # Where middle 40% of features are informative and have correlation of rho
    # with each other, and the other 60% of features are independent of each other
    # and the informative image features
    block1 <- matrix(0, nrow = .3*q,ncol = .3*q)
    diag(block1) <- rep(1,.3*q)
    
    block2 <- matrix(rho, nrow = .4*q,ncol = .4*q)
    diag(block2) <- rep(1,.4*q)
    
    covariance_blocks <- list(block1, block2, block1)
    col_cov_matrix <- bdiag(covariance_blocks)
    col_cov_matrix <- as.matrix(col_cov_matrix)
    
    # Row covariance matrix
    row_cov_matrix <- matrix(0,nrow=G,ncol=G)
    
    diag(row_cov_matrix) <- c(sigma1,sigma2)
    
    # Generate latent tubular feature averages from a multivariate normal 
    # distribution with specified row and column covariance structures
    Xi_star <- rmatrixnorm(n=1,mean=mean_matrix,U=row_cov_matrix,V=col_cov_matrix)     
    
    # Resample latent tubular feature averages with replacement to generate observed feature
    # matrices (pi tubules for subject i), and resample the different clusters 
    # in proportion to the average proportion of tubules in each cluster defined by w and 1-w
    resamp.Xi.rows <- sample(1:nrow(Xi_star), size=p[j], replace=T,prob=c(w[j],1-w[j]))
    
    # Draw the resampled tubules 
    resamp.Xi <- Xi_star[resamp.Xi.rows,]
    
    # Adding standard normal Gaussian measurement error to each resampled tubule
    resamp.Xi <- resamp.Xi + rnorm(nrow(resamp.Xi)*ncol(resamp.Xi),sd=sqrt(sigma.r))
    
    X <- resamp.Xi
    
    # Adding observed Xi to list of all Xi
    raw.X[[j]] <- X
    
    ### Multiply the latent tubluar feature averages by the true, latent proportion 
    ## of tubules that should be in each cluster
    Xi_star[1,] <- w[j] * Xi_star[1,]
    Xi_star[2,] <- (1-w[j]) * Xi_star[2,]
    
    # Generate the observed outcome with measurement error in the outcome and 
    # coefficient weighting for the cluster-level effects and image features
    Y[j] <- t(alpha_star) %*% Xi_star %*% beta_star + rnorm(n=1,mean=0,sd=sqrt(sigma_sq))
    
    # Naive feature metric where feature values are averaged across all tubules
    # per subject
    X.avg[j,] <- colMeans(X)
    
  }
  
  # Concatenate all tubules in one big matrix for clustering 
  X.all <- do.call(rbind, raw.X)
  
  # Do Gaussian mixture model-based clustering, classifying all tubules
  # across all subjects into one of two clusters
  NMM.out <- Mclust(X.all,G=G)$classification
  
  # For each observed feature matrix Xi's, make the first column the estimated
  # clustering labels
  for(i in 1:n)
  {
    raw.X[[i]] <- cbind(NMM.out[1:p[i]],raw.X[[i]])
    NMM.out <- NMM.out[(p[i]+1):length(NMM.out)]
  }
  
  # Matrices for CLUSSO have dimension 2 x number of image features x number of subjects
  clust.X <- array(1, dim=c(G,q,n))
  
  # Average feature values within each cluster and weight the resulting averages
  # by the proportion of tubules observed in each cluster
  for(i in 1:n)
  {
    clust1.X <- raw.X[[i]][raw.X[[i]][,1]==1,]
    clust2.X <- raw.X[[i]][raw.X[[i]][,1]==2,]
    
    w1 <- nrow(clust1.X)/nrow(raw.X[[i]])
    
    clust.X[,,i] <- rbind(w1*apply(clust1.X[,2:ncol(clust1.X)],MARGIN=2,mean),
                          (1-w1)*apply(clust2.X[,2:ncol(clust2.X)],MARGIN=2,mean))
    
  }
  
  return(list(Y,X.avg,clust.X,raw.X))
}