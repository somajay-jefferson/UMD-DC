# Author: Jeremy Rubin
# Example code to do data analysis with Random CLUSSO, CLUSSO, and the naive approach
# Date: 11/29/24

rm(list=ls())

library(glmnet)
library(mclust)
library(MixMatrix)
set.seed(87543)

source("Random_CLUSSO_non_mainfunctions.R")
source("Mainfunction_albet.R")
source("Mainfunction_albet_Structured_OLS.R")
source("coefficient.R")
source("K_prdu.R")
source("mat_vec_prd.R")

########## Parameters to simulate data
# Sample size
n <- 100

# Correlation between informative predictors
rho <- 0.9

# Variance of pi's 
sigma_sq_m <- 5

# Average number of pi's
mu <- 100

# Variance of outcome
sigma_sq <- 1

# Mean of tubules in cluster 1
x1 <- 5

# Mean of tubules in cluster 2
x2 <- 10

# Variance of tubules in cluster 1
sigma1 <- 1

# Variance of tubules in cluster 2
sigma2 <- 3

# Noise in resampled tubules
sigma.r <- 1

# Percentage of tubules in cluster 1 for each subject
w <- sample(seq(0.2,0.8,0.1),size=n,replace=T)

# Simulating true cluster-level effects
alpha_star <- sample(1:4,size=2,replace=TRUE)

# Number of image features
q <- 10

# Simulating true image feature-level effects
# First and last 30% of features are uninformative of outcome
# Middle 40% of features are informative
beta_star <- c(rep(0,.3*q),rep(3,.4*q),rep(0,.3*q))

########## Parameters to be acquired from real data or ones to set to analyze real data
# Coefficient threshold 
thresh <- 0.01

# Number of bootstrap iterations per round of bootstrapping for Random CLUSSO
# Recommend B = 200 bootstraps or more in practice
B <- 5

# Grid of optimization parameters to optimize CLUSSO/Random CLUSSO over 
lambda.grid <- seq(0.1,20,0.1)

data.observed <- generate.data(n,mu,sigma_sq_m,sigma_sq,
                         x1,x2,sigma1,sigma2,
                         sigma.r,alpha_star,beta_star,
                         w,rho)

# Outcome vector
Y <- data.observed[[1]]

# Naive approach feature matrix
X.avg <- data.observed[[2]]

# Cluster-averaged and weighted feature matrices for CLUSSO
clust.X <- data.observed[[3]]

# Original unbalanced feature matrices
raw.X <- data.observed[[4]]

# 80/20 training/testing split
n <- length(Y)
train.ind <- sort(sample(1:n,replace = F,size = floor(.8*n)))
test.ind <- sort(setdiff(1:n,train.ind))
  
Y.train <- Y[train.ind]
Y.test <- Y[test.ind]
  
X.avg.train <- X.avg[train.ind,]
X.avg.test <- X.avg[test.ind,]
  
raw.X.train <- raw.X[train.ind]
raw.X.test <- raw.X[test.ind]

clust.X.train <- clust.X[,,train.ind]
clust.X.test <- clust.X[,,test.ind]

### For real data, because CLUSSO isn't guaranteed to reach a global 
### optimum, can take the best result for five choices of alpha's/beta's
M <- 5
obj.CLUSSO.vec <- rep(0,M)

beta.matrix <- matrix(0,nrow=M,ncol=dim(clust.X.train)[2])
alpha.matrix <- matrix(0,nrow=M,ncol=dim(clust.X.train)[1])
lambda.save <- rep(0,M)

# Scale outcomes
Y.train <- scale(Y.train,scale=FALSE)
Y.test <- scale(Y.test,scale=FALSE)

# Calculate averages for each feature across subjects
X.mean.train <- apply(clust.X.train, c(1,2), mean)
X.mean.test <- apply(clust.X.test, c(1,2), mean)

# Calculate centered feature matrices
cent.clust.X.train <- clust.X.train
cent.clust.X.test <- clust.X.test

for(d in 1:length(train.ind))
{
  cent.clust.X.train[,,d] <- cent.clust.X.train[,,d] - X.mean.train
}

for(r in 1:length(test.ind))
{
  cent.clust.X.test[,,r] <- cent.clust.X.test[,,r] - X.mean.test
}

# Do five runs of CLUSSO calculating alpha/beta and computing the value 
# of the objective function
# Pick the alpha and beta which correspond to the the minimum value of the
# objective function
for(m in 1:M)
{
  print(paste(m))
  
  # Random, non-zero initializations of alpha and beta 
  # coefficient vectors
  alpha_init <- rnorm(2)
  beta_init <- rnorm(dim(clust.X.train)[2])
  
  # Compute MSEs over grid of lambdas
  mse.clust.lambda <- sapply(lambda.grid,lambda.CV.mse,
                             X.train=clust.X.train,
                             Y.train=Y.train,
                             alpha_init=alpha_init,
                             beta_init=beta_init,
                             thresh=thresh)
  
  # Pick the lambda that corresponds to minimum MSE
  lambda.clust <- lambda.grid[which(mse.clust.lambda==min(mse.clust.lambda))][1]
  
  # EStimate alpha and beta using structured lasso on the
  # Cluster-averaged and weighted feature matrices
  CLUSSO.fit <- Mainfunction_albet(clust.X.train,Y.train,
                                   alpha_init,
                                   beta_init,
                                   lambda.clust,
                                   thresh=thresh)
  alpha_hat <- CLUSSO.fit[[1]]
  beta_hat <- CLUSSO.fit[[2]]
  
  beta.matrix[m,] <- beta_hat
  alpha.matrix[m,] <- alpha_hat
  lambda.save[m] <- lambda.clust
  
  obj <- 0
  
  # Compute value of objective function for choice of alpha hat/beta hat
  for(k in 1:length(train.ind))
  {
    obj <- obj + 
      (Y.train[k] - t(alpha_hat) %*% cent.clust.X.train[,,k] %*% beta_hat)^2
  }
  
  obj <- (1/n)*obj + sum(abs(beta_hat))*sum(abs(alpha_hat))*lambda.clust
  
  obj.CLUSSO.vec[m] <- obj
} 

# Beta, alpha, and lambda that correspond to minimizing the objective function
beta_hat <- beta.matrix[which(obj.CLUSSO.vec==min(obj.CLUSSO.vec)),]
alpha_hat <- alpha.matrix[which(obj.CLUSSO.vec==min(obj.CLUSSO.vec)),]
lambda.clust <- lambda.save[which(obj.CLUSSO.vec==min(obj.CLUSSO.vec))] 

## Compute beta hat for naive approach
avg.fit <- cv.glmnet(X.avg.train,Y.train,nfolds = 5)
beta_coeff <- as.vector(coef(avg.fit, s = "lambda.min"))
intercept <- beta_coeff[1]
beta_hat.avg <- beta_coeff[-1]

# Normalize and threshold naive beta hat
beta_hat.avg.original <- beta_hat.avg
beta_hat.avg <- beta_hat.avg/sum(abs(beta_hat.avg))
zero.inds <- abs(beta_hat.avg)<0.01
beta_hat.avg[abs(beta_hat.avg)<0.01]=0

# Compute MSE for the naive approach 
beta_hat.avg.original[zero.inds]=0
SSE <- 0

for(r in 1:length(test.ind))
{
  SSE <- SSE + (Y.test[r]-beta_hat.avg.original %*% X.avg.test[r,] - intercept)^2
}

MSE.avg <- (1/length(test.ind)) * SSE

# Compute MSE for CLUSSO
SSE.CLUSSO <- 0
for(b in 1:length(test.ind))
{
  SSE.CLUSSO <- SSE.CLUSSO + (Y.test[b] - t(alpha_hat) %*% cent.clust.X.test[,,b] %*% beta_hat)^2  
}

MSE.CLUSSO <- (1/length(test.ind)) * SSE.CLUSSO

# Compute MSE for CLUSSO if you flipped the alpha coefficients
SSE.CLUSSO.flipped <- 0
for(b in 1:length(test.ind))
{
  SSE.CLUSSO.flipped <- SSE.CLUSSO.flipped + 
    (Y.test[b] - t(alpha_hat[c(2,1)]) %*% cent.clust.X.test[,,b] %*% beta_hat)^2  
}

MSE.CLUSSO.flipped <- (1/length(test.ind)) * SSE.CLUSSO.flipped

### Do first round of bootstrapping for Random CLUSSO
### Passing in weights of all zeros to indicate that image features
### will be subsampled uniformly 
### Also keep in mind for raw.X, the first column of each matrix in this list
### are the estimated cluster labels
beta.matrix.plus.clust <- sapply(1:B,
                                 FUN=bootstrap.estimates,
                                 raw.X=raw.X.train,
                                 Y=Y.train,
                                 lambda.grid=lambda.grid,
                                 sample.weights=rep(0,q),
                                 thresh=thresh,
                                 simplify=FALSE)

# Reformat results into a matrix
### The result returned by each iteration of generae.importance.betas 
### is a numeric matrix of the form (alpha hat, beta hat), where we know
### alpha hat is of length 2 for two clusters
beta.matrix.reformat <- matrix(0,nrow=B,ncol=q+2)
for(i in 1:B){beta.matrix.reformat[i,] <- beta.matrix.plus.clust[[i]]}

## Importance measure for each predictor is the absolute value of the average
## of bootstrapped coefficients
importance.measures <- apply(beta.matrix.reformat,MARGIN=2,mean)
importance.measures <- abs(importance.measures)

# Extract just the portion of the results that corresponds to indices for 
# beta hat
beta.importance <- importance.measures[3:length(importance.measures)]

# Second round of bootstrapping for Random CLUSSO where this time, image features
# are subsampled in proportion to the importance measures
beta.matrix.final <- sapply(1:B,
                            FUN=bootstrap.estimates,
                            raw.X=raw.X.train,
                            Y=Y.train,
                            lambda.grid=lambda.grid,
                            sample.weights=beta.importance,
                            thresh=thresh,
                            simplify=FALSE)

# Reformat results into a matrix
# Results are in same format as for first round of bootstrapping
beta.matrix.final.reformat <- matrix(0,nrow=B,ncol=q+2)
for(i in 1:B){beta.matrix.final.reformat[i,] <- beta.matrix.final[[i]]}

### Average Random CLUSSO results across round 2 of bootstrapping
final.avg <- apply(beta.matrix.final.reformat,MARGIN=2,mean)

# Extract the averaged beta hat estimate from round 2 of bootstrapping
final.avg.beta <- final.avg[3:length(final.avg)]

# Non-normalized bootstrap-averaged beta hat 
final.avg.beta.non.normalized <- final.avg.beta

# Random CLUSSO beta hat thresholding
final.avg.beta <- final.avg.beta/sum(abs(final.avg.beta))
small.inds <- abs(final.avg.beta)<thresh
final.avg.beta[small.inds]=0
final.avg.beta.non.normalized[small.inds]=0

# Compute Random CLUSSO MSE using what we call the structured ordinary least squares
# We start by taking the CLUSSO balanced and weighted feature matrices and subsetting 
# the image features chosen by Random CLUSSO
features.to.keep <- final.avg.beta.non.normalized!=0
MSE.clust.X <- array(1, dim=c(2,sum(features.to.keep),length(test.ind)))

for(i in 1:length(test.ind))
{
  MSE.clust.X[,,i] <- clust.X.test[,features.to.keep==T,i]
}

# Then, do a structured OLS fit using the new feature matrices
beta_init <- rnorm(dim(MSE.clust.X)[2])
Random_CLUSSO_MSE_fit <- Mainfunction_albet_OLS(X_tr=MSE.clust.X,
                                                Y_tr=Y.test,
                                                alpha=alpha_init,
                                                bet=beta_init)

# Compute alpha hat and beta hat
Random_CLUSSO_MSE_alpha <- Random_CLUSSO_MSE_fit[[1]]
Random_CLUSSO_MSE_beta <- Random_CLUSSO_MSE_fit[[2]]

# Calculate averages for each feature across subjects
X.mean.MSE <- apply(MSE.clust.X, c(1,2), mean)

# Mean center Xi's for Random CLUSSO MSE
cent.clust.X.MSE <- MSE.clust.X
for(d in 1:length(test.ind)){cent.clust.X.MSE[,,d] <- cent.clust.X.MSE[,,d] - X.mean.MSE}

# Compute MSE for Random CLUSSO
SSE.Random.CLUSSO <- 0
for(b in 1:length(test.ind))
{
  SSE.Random.CLUSSO <- 
    SSE.Random.CLUSSO + (Y.test[b] - 
                           t(Random_CLUSSO_MSE_alpha) %*% 
                           cent.clust.X.MSE[,,b] %*% Random_CLUSSO_MSE_beta)^2  
}

MSE.Random.CLUSSO <- (1/length(test.ind)) * SSE.Random.CLUSSO

# Compute MSE for Random CLUSSO with alpha coefficients flipped
SSE.Random.CLUSSO.flipped <- 0
for(b in 1:length(test.ind))
{
  SSE.Random.CLUSSO.flipped <- 
    SSE.Random.CLUSSO.flipped + (Y.test[b] - 
                           t(Random_CLUSSO_MSE_alpha[c(2,1)]) %*% 
                           cent.clust.X.MSE[,,b] %*% Random_CLUSSO_MSE_beta)^2  
}

MSE.Random.CLUSSO.flipped <- (1/length(test.ind)) * SSE.Random.CLUSSO.flipped

combined.coeff <- cbind(beta_hat,beta_hat.avg,final.avg.beta)
colnames(combined.coeff) <- c("CLUSSO","Naive approach","Random CLUSSO")

paste("Naive approach lambda min: ",avg.fit$lambda.min)
paste("CLUSSO lambda: ",lambda.clust)

paste("Naive approach MSE: ",MSE.avg)
paste("CLUSSO MSE: ",MSE.CLUSSO)
paste("CLUSSO MSE with alpha coefficients flipped: ",MSE.CLUSSO.flipped)
paste("Random CLUSSO MSE: ",MSE.Random.CLUSSO)

lambda.vec <- c(avg.fit$lambda.min,lambda.clust)
names(lambda.vec) <- c("Naive lambda","CLUSSO lambda")

MSE.vec <- c(MSE.avg,MSE.CLUSSO,MSE.CLUSSO.flipped,MSE.Random.CLUSSO,MSE.Random.CLUSSO.flipped)
names(MSE.vec) <- c("Naive MSE","CLUSSO MSE","CLUSSO MSE alpha flipped","Random CLUSSO MSE","Random CLUSSO MSE alpha flipped")

alpha_mat <- cbind(alpha_hat,Random_CLUSSO_MSE_alpha)
colnames(alpha_mat) <- c("CLUSSO alpha","Random CLUSSO MSE alpha")

paste("Estimated image feature effects")
print(combined.coeff)

print("Lambda values")
print(lambda.vec)

paste("MSEs")
print(MSE.vec)