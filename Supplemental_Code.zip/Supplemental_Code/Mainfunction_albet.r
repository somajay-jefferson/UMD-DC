Mainfunction_albet<-function(X_tr,Y_tr,alpha,bet,lambda,thresh)
{## obtain the estimate of alpha and beta by  structured lasso method, 
#using the iterative lasso on data (Y, \alpha*X) and (Y, X*\beta) respectively. 
#1. (X_tr,Y_tr) taining data; X_tr[:,:,k] for k=1,2,..n.  are i.i.d matrix observations. Y_tr is column vector cosisting of i.i.d. observations. 
#2. (alpha, bet) are the nonzero initial value for  the parameter \alpha and \beta; 
#3. lambda is fixed  tuning parameter;
#4. thresh is the threshold used to zero out sufficiently small coefficients
  
# library(glmnet)
# source("K_prdu.r")  # the  path should be replaced by user
# source("coefficient.r")
# source("mat_vec_prd.r")
d_tr=dim(X_tr);  

dif=100; nrun=0;
sig_al=sign(alpha[which.max(abs(alpha))])
alpha=sig_al*alpha/sum(abs(alpha));           # standardize alpha such that it has unit L1 norm. 
 while((dif>0.01)&&(nrun<50)&&(max(abs(alpha))>0)&&(max(abs(bet))>0)) 
{ nrun=nrun+1;
 bet0=bet;
 alpha0=alpha; nr_alpha0=sum(abs(alpha0))
 
  X_alpha=mat_vec_prd(X_tr,alpha,ord='vec_mat')  # obtain the i.i.d observation of  \alpha*X

 fit1=glmnet(X_alpha,Y_tr,'lambda'=lambda*sum(abs(alpha)))      # fit (Y, \alpha*X)  by lasso to get estimate of \beta
 bet=fit1$beta[,1]
 bet=matrix(bet[(length(bet)-d_tr[2]+1):length(bet)],ncol=1)
 
 if (max(abs(bet))>0)
 {sig_bet=sign(bet[which.max(abs(bet))]); 
 bet=sig_bet*bet/sum(abs(bet));} 
 
 X_bet=mat_vec_prd(X_tr,bet,ord='mat_vec')#  obtain the i.i.d observation of  X*\beta
 
 if (max(abs(bet))>0)
 {
 
 # Do ordinary least squares fit instead of lasso for alpha 
 # So that alpha coefficients aren't necessarily zerod out   
 # obj1=coefficient(X_bet,Y_tr,lambda*sum(abs(bet)));    # fit (Y,X*\beta) by lasso  to get the estimate of \alpha
 # alpha=matrix(unlist(obj1$b),ncol=1)
   fit1 = lm(Y_tr ~ X_bet)
   alpha = matrix(fit1$coefficients[-1])
   alpha=matrix(alpha[(length(alpha)-d_tr[1]+1):length(alpha)],ncol=1)
 }
  nr_alpha=max(c(0,sum(abs(alpha))));
  
 if ((max(abs(alpha)))>0)
 {sig_al=sign(alpha[which.max(abs(alpha))]);
  alpha=sig_al*alpha/sum(abs(alpha));}  
  
 dif=norm(K_prdu(bet,alpha)-K_prdu(bet0,alpha0),"F")        # compute the difference between estimate \beta\otimes \alpha and \beta_0\otimes \alpha_0
}
alpha[abs(alpha)<thresh]=0;
bet[abs(bet)<thresh]=0
alpha=nr_alpha*alpha;
albet=list('alpha'=alpha,'bet'=bet)
}