coefficient<-function(x,y,Lamd)
{ #glmnet to make the estimate


d=dim(x); n=d[1];
if (length(Lamd)!=0)
{
fit1=glmnet(x,y,'lambda'=Lamd)
b=fit1$beta[,1]
} else {
fit1=glmnet(x,y)
D=deviance(fit1)
In=which.min(D+fit1$df*log(n))
b=fit1$beta[,In]
}


b=matrix(unlist(b),nrow=length(b))
if  (length(Lamd)!=0)
{obj=list('b'=b)
}else{
obj=list('b'=b,'lamd'=fit1$lambda)
}
obj

}
  #fit1$lambda 

#coef(fit1,s=0.1)