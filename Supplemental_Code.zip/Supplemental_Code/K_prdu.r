K_prdu<-function(A,B)
{ # the Kroneck product A*o*B of two vector;
d_a=length(A);
d_b=length(B);
vec=vector();
for (i in 1:d_a)
{ for (j in 1:d_b)
{vec[(i-1)*d_b+j]=A[i]*B[j]
}
} 
dim(vec)=c(d_a*d_b,1)
vec
}