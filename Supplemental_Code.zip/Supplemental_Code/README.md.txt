# Code for Analysis of Correlated Image Features using Scalar-on-matrix Paper

This code provides a framework for analyzing data in a scalar-on-matrix regression setting where the feature matrices have different numbers of rows and the image features are correlated 

All R scripts except for Random_CLUSSO_Data_Analysis.R provide helper functions to run the Random_CLUSSO_Data_Analysis.R Script. 

## Installation

To run these scripts, you need to have R installed. You can install the required packages by using the following commands:

```R
install.packages("glmnet")
install.packages("mclust")
install.packages("MixMatrix")
```

## Usage

1. First, load the necessary packages and helper functions: 

```R
library(glmnet)
library(mclust)
library(MixMatrix)

source("Random_CLUSSO_non_mainfunctions.R")
source("Mainfunction_albet.R")
source("Mainfunction_albet_Structured_OLS.R")
source("coefficient.R")
source("K_prdu.R")
source("mat_vec_prd.R")```

2. Choose values of parameters for data generation. This includes setting the 

Sample size (n)

Correlation between informative predictors (rho)

Average number of pi's and variance of pi's (mu, sigma_sq_m)

Variance of outcome (sigma_sq)

Mean of tubules in cluster 1 and cluster 2 (x1,x2)

Variances of tubules in cluster 1 and cluster 2 (sigma1, sigma2)

Noise in resampled tubules (sigma.r)

Percentage of tubules in cluster 1 for each subject (w)

True coefficient vectors (alpha_star, beta_star)

Number of image features (q)

Coefficient vector threshold for beta star (thresh)

Number of bootstrap iterations per round of bootstrapping for Random CLUSSO (B)

Grid of optimization parameters to optimize CLUSSO/Random CLUSSO over (lambda.grid)

Some hard coding of 2's reflect the fact that CLUSSO/Random CLUSSO is based on two underlying tubular clusters

3. Do the analysis! 

The Random_CLUSSO_Data_Analysis.R script will perform Random CLUSSO, CLUSSO and the naive averaging approach on the synthetic scalar-on-matrix regression method, again assuming we are interested in identifying two clusters to generate estimated beta_star coefficients as well mean squared error (MSEs) on the same data used to estimate the beta_star coefficients. 

## Contact Information

For questions about the code, please reach the first-author, Jeremy Rubin, of the corresponding manuscript at RubinJ@pennmedicine.upenn.edu 




